MR. FRUIT CORNER — WEBSITE EDITABLE
===================================

ISI PAKET
---------
- index.html : website utama, responsif untuk desktop, tablet, dan mobile.
- assets/    : logo asli, referensi kemasan, dan foto-foto buah dari ZIP.

EDIT WEBSITE
------------
1. Buka index.html dengan Visual Studio Code, Notepad++, atau editor teks lain.
2. Teks halaman, warna, layout, navigasi mobile, tautan, dan interaksi ada di index.html.
3. Variabel warna berada di bagian awal CSS:
   --site-primary: #176b36;
   --site-secondary: #f4d524;
   --site-background: #fffdf3;
4. Daftar produk dan harga berada di JavaScript dengan nama `const products`.
5. Foto buah, logo, dan foto kemasan disertakan di folder assets sebagai file sumber. HTML juga menyematkan gambar agar dapat dibuka sebagai satu file mandiri.
6. Menu hamburger pada layar kecil dapat dibuka/ditutup; memilih tautan akan menutup menu. Filter Juice/Slice dan pencarian produk juga interaktif.

BUKA DI KOMPUTER
----------------
Klik dua kali index.html untuk membukanya di browser. Tidak perlu instalasi.
Untuk mengubah website, edit index.html lalu simpan dan refresh browser.

CARA PUBLIKASI ONLINE (GRATIS)
------------------------------
Opsi A — Netlify Drop:
1. Ekstrak file ZIP ini.
2. Buka https://app.netlify.com/drop dan login/daftar.
3. Unggah folder `Mr-Fruit-Corner-Website` hasil ekstrak (pastikan index.html berada di root folder tersebut).
4. Ikuti instruksi Netlify untuk memperoleh alamat website publik.

Opsi B — GitHub Pages:
1. Buat repository GitHub baru.
2. Unggah index.html ke root repository; folder assets boleh ikut disertakan sebagai file sumber.
3. Buka Settings > Pages, pilih deploy dari branch utama dan folder root, lalu simpan.
4. Tunggu proses publikasi selesai.

PERIKSA SEBELUM TAYANG
----------------------
- Nomor WhatsApp yang digunakan saat ini: +62 817-1753-6330. Pastikan nomor ini benar dan aktif.
- Instagram dan TikTok menggunakan @mr.fruitcorner. Pastikan nama akun benar.
- GoFood, GrabFood, dan ShopeeFood ditampilkan sebagai kanal yang tersedia. URL langsung ke halaman toko belum ditambahkan karena tautan toko belum diberikan.
- Periksa kembali harga dan ketersediaan menu sebelum publikasi.
- Foto buah pada menu adalah ilustrasi jenis buah dari ZIP; foto kemasan menggunakan referensi yang dilampirkan.
- Preview dalam ChatGPT bukan situs publik; publikasi perlu dilakukan melalui layanan hosting.
